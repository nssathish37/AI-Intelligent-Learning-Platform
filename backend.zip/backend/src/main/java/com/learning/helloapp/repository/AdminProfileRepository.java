package com.learning.helloapp.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.learning.helloapp.model.AdminProfile;

public interface AdminProfileRepository 
       extends MongoRepository<AdminProfile, String> {
              
}
