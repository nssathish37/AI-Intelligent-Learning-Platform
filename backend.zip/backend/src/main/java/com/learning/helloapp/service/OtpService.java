package com.learning.helloapp.service;

import com.learning.helloapp.model.OtpEntity;
import com.learning.helloapp.repository.OtpRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class OtpService {

    private final OtpRepository otpRepository;

    public OtpService(OtpRepository otpRepository) {
        this.otpRepository = otpRepository;
    }

    public String generateOtp(String email) {
        // delete old OTP
        otpRepository.deleteByEmail(email);

        String otp = String.format("%06d", new Random().nextInt(999999));

        OtpEntity entity = new OtpEntity();
        entity.setEmail(email);
        entity.setOtp(otp);
        entity.setExpiryTime(LocalDateTime.now().plusMinutes(5));

        otpRepository.save(entity);

        return otp;
    }

    public boolean verifyOtp(String email, String otp) {

    System.out.println("EMAIL RECEIVED: " + email);
    System.out.println("OTP RECEIVED: '" + otp + "'");

    var latestOtp = otpRepository.findTopByEmailOrderByExpiryTimeDesc(email);

    if (latestOtp.isEmpty()) {
        System.out.println("No OTP found in DB");
        return false;
    }

    OtpEntity entity = latestOtp.get();

    System.out.println("OTP IN DB: '" + entity.getOtp() + "'");
    System.out.println("EXPIRY: " + entity.getExpiryTime());

    otp = otp.trim();

    if (LocalDateTime.now().isAfter(entity.getExpiryTime())) {
        System.out.println("OTP expired");
        return false;
    }

    if (!entity.getOtp().equals(otp)) {
        System.out.println("OTP does not match");
        return false;
    }

    otpRepository.deleteByEmail(email);
    System.out.println("OTP verified successfully");

    return true;
   }
}
