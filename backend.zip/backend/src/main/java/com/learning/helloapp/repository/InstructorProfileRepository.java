package com.learning.helloapp.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.learning.helloapp.model.InstructorProfile;

public interface InstructorProfileRepository 
       extends MongoRepository<InstructorProfile, String> {
              
}
