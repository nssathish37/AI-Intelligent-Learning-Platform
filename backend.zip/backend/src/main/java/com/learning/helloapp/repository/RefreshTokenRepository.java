package com.learning.helloapp.repository;

import com.learning.helloapp.model.RefreshToken;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RefreshTokenRepository
        extends MongoRepository<RefreshToken, String> {

    RefreshToken findByToken(String token);

    void deleteByEmail(String email);
}
