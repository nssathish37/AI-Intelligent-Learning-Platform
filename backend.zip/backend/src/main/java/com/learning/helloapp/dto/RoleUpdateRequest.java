package com.learning.helloapp.dto;

public class RoleUpdateRequest {

    private String role;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
