package com.learning.helloapp.model;

public enum Role {
    STUDENT,
    INSTRUCTOR,
    ADMIN
}
