package com.learning.helloapp.repository;

import com.learning.helloapp.model.OtpEntity;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface OtpRepository extends MongoRepository<OtpEntity, String> {
    Optional<OtpEntity> findTopByEmailOrderByExpiryTimeDesc(String email);

    void deleteByEmail(String email);
}
