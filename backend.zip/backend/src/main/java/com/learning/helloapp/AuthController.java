package com.learning.helloapp;

import com.learning.helloapp.dto.LoginRequest;
import com.learning.helloapp.dto.RegisterRequest;
import com.learning.helloapp.dto.OtpVerifyRequest;
import com.learning.helloapp.model.RefreshToken;
import com.learning.helloapp.model.User;
import com.learning.helloapp.repository.RefreshTokenRepository;
import com.learning.helloapp.repository.UserRepository;
import com.learning.helloapp.security.JwtService;
import com.learning.helloapp.service.EmailService;
import com.learning.helloapp.service.OtpService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import org.springframework.beans.factory.annotation.Autowired;
import com.learning.helloapp.model.StudentProfile;
import com.learning.helloapp.repository.StudentProfileRepository;
import com.learning.helloapp.dto.StudentProfileRequest;

import java.util.Map;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final OtpService otpService;
    private final EmailService emailService;
    private final UserRepository userRepository;
    private final JwtService jwtService;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    private StudentProfileRepository studentProfileRepository;

    public AuthController(
            OtpService otpService,
            EmailService emailService,
            UserRepository userRepository,
            JwtService jwtService,
            RefreshTokenRepository refreshTokenRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.otpService = otpService;
        this.emailService = emailService;
        this.userRepository = userRepository;
        this.jwtService = jwtService;
        this.refreshTokenRepository = refreshTokenRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ================= REGISTER =================
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {

        System.out.println("REGISTER API CALLED");
        System.out.println("EMAIL: " + request.getEmail());
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            return ResponseEntity.badRequest()
            .body(Map.of("error", "Email already registered"));
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole());
        new SimpleGrantedAuthority("ROLE_" + user.getRole());
        
        userRepository.save(user);

        // 🔥 GENERATE OTP
        String otp = otpService.generateOtp(user.getEmail());

        // 🔥 SEND OTP EMAIL
        emailService.sendOtpEmail(user.getEmail(), otp);

        return ResponseEntity.ok(Map.of(
            "message", "User registered successfully. OTP sent to email."
        ));
    }

    // ================= LOGIN =================
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
            .orElseThrow(() -> new RuntimeException("Invalid email"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Invalid credentials"));
        }

        // 🔥 Generate OTP instead of token
        String otp = otpService.generateOtp(user.getEmail());
        emailService.sendOtpEmail(user.getEmail(), otp);

        return ResponseEntity.ok(
            Map.of("message", "OTP sent to your email")
       );
    }

    // ================= SEND OTP =================
    @PostMapping("/send-otp")
    public ResponseEntity<?> sendOtp(@RequestBody Map<String, String> request) {

        String email = request.get("email");

        String otp = otpService.generateOtp(email);
        emailService.sendOtpEmail(email, otp);

        return ResponseEntity.ok(Map.of("message", "OTP sent"));
    }

    // ================= VERIFY OTP =================
    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOtp(@RequestBody OtpVerifyRequest request) {

        boolean ok = otpService.verifyOtp(
                request.getEmail(),
                request.getOtp()
        );

        if (!ok) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Invalid OTP"));
        }

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow();

        String accessToken = jwtService.generateAccessToken(user);
        String refreshToken = jwtService.generateRefreshToken(user);

        refreshTokenRepository.deleteByEmail(user.getEmail());

        RefreshToken tokenEntity = new RefreshToken();
        tokenEntity.setEmail(user.getEmail());
        tokenEntity.setToken(refreshToken);
        refreshTokenRepository.save(tokenEntity);

        return ResponseEntity.ok(Map.of(
                "message", "OTP verified successfully",
                "user", user,
                "accessToken", accessToken,
                "refreshToken", refreshToken
        ));
    }

    // ================= REFRESH TOKEN =================
    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@RequestBody Map<String, String> body) {

        String refreshToken = body.get("refreshToken");

        RefreshToken stored =
                refreshTokenRepository.findByToken(refreshToken);

        if (stored == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Invalid refresh token"));
        }

        String email = jwtService.extractEmail(refreshToken);

        User user = userRepository.findByEmail(email)
                .orElseThrow();

        String newAccessToken =
                jwtService.generateAccessToken(user);

        return ResponseEntity.ok(
                Map.of("accessToken", newAccessToken)
        );
    }

    // ================= LOGOUT =================
    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestBody Map<String, String> body) {

        String email = body.get("email");

        refreshTokenRepository.deleteByEmail(email);

        return ResponseEntity.ok(
                Map.of("message", "Logged out successfully")
        );
    }

    @PostMapping("/student/profile")
    public ResponseEntity<?> saveOrUpdateProfile(
        @RequestBody StudentProfileRequest request) {

        StudentProfile profile = studentProfileRepository
            .findByEmail(request.getEmail())
            .orElse(new StudentProfile());

        profile.setEmail(request.getEmail());
        profile.setDegree(request.getDegree());
        profile.setDepartment(request.getDepartment());
        profile.setYear(request.getYear());
        profile.setCareerGoal(request.getCareerGoal());
        profile.setSkillLevel(request.getSkillLevel());

        studentProfileRepository.save(profile);

        return ResponseEntity.ok(
            Map.of("message", "Profile saved/updated successfully")
        );
    }

    @GetMapping("/student/profile/check")
    public ResponseEntity<?> checkStudentProfile(@RequestParam String email) {

        boolean exists = studentProfileRepository
            .findByEmail(email)
            .isPresent();

            return ResponseEntity.ok(
            Map.of("profileCompleted", exists)
        );
    }

    @GetMapping("/student/profile")
    public ResponseEntity<?> getStudentProfile(@RequestParam String email) {

        return studentProfileRepository.findByEmail(email)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
}