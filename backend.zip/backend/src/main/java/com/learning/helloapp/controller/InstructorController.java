package com.learning.helloapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;

import com.learning.helloapp.model.InstructorProfile;
import com.learning.helloapp.repository.InstructorProfileRepository;

@RestController
@RequestMapping("/api/instructor")
@CrossOrigin(origins = "http://localhost:5173")
public class InstructorController {

    @Autowired
    private InstructorProfileRepository repository;

    @PostMapping("/profile")
    public ResponseEntity<InstructorProfile> createProfile(
            @RequestBody @NonNull InstructorProfile profile) {

        InstructorProfile savedProfile = repository.save(profile);

        return ResponseEntity.ok(savedProfile);
    }
}