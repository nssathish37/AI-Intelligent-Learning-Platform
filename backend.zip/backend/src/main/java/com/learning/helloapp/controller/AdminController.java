package com.learning.helloapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;

import com.learning.helloapp.model.User;
import com.learning.helloapp.repository.UserRepository;
import com.learning.helloapp.dto.RoleUpdateRequest;
import com.learning.helloapp.model.AdminProfile;
import com.learning.helloapp.repository.AdminProfileRepository;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:5173")
public class AdminController {

    @Autowired
    private AdminProfileRepository repository;

    @Autowired
    private UserRepository userRepository;

    // ✅ Get all users
    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }
    // ✅ Update user role
    @PutMapping("/users/{id}/role")
    public ResponseEntity<?> updateUserRole(
            @PathVariable String id,
            @RequestBody RoleUpdateRequest request) {

        if (id == null || id.isBlank()) {
            return ResponseEntity.badRequest().body("Invalid user ID");
        }

        if (request == null || request.getRole() == null || request.getRole().isBlank()) {
            return ResponseEntity.badRequest().body("Role is required");
        }

        User user = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("User not found"));

        user.setRole(request.getRole());
        userRepository.save(user);

        return ResponseEntity.ok("Role updated successfully");
    }

     // ✅ Delete user
    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable String id) {

        if (id == null || id.isBlank()) {
            return ResponseEntity.badRequest().body("Invalid ID");
        }

        if (!userRepository.existsById(id)) {
            return ResponseEntity.badRequest().body("User not found");
        }

        userRepository.deleteById(id);

        return ResponseEntity.ok("User deleted successfully");
    }

    @PostMapping("/profile")
    public ResponseEntity<AdminProfile> createProfile(
            @RequestBody @NonNull AdminProfile profile) {

        AdminProfile savedProfile = repository.save(profile);

        return ResponseEntity.ok(savedProfile);
    }

    @GetMapping("/analytics")
    public ResponseEntity<?> analytics() {

        long totalUsers = userRepository.count();
        long instructors = userRepository.countByRole("INSTRUCTOR");
        long students = userRepository.countByRole("STUDENT");
        
        long totalAssessments = assessmentRepository.count();
        long totalInterviews = interviewRepository.count();

        Map<String, Object> response = new HashMap<>();

        response.put("totalUsers", totalUsers);
        response.put("totalStudents", totalStudents);
        response.put("totalInstructors", totalInstructors);
        response.put("totalAssessments", totalAssessments);
        response.put("totalInterviews", totalInterviews);
        return ResponseEntity.ok(response);
    }
}