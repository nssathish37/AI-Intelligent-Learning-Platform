package com.learning.helloapp.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.learning.helloapp.model.StudentProfile;

public interface StudentProfileRepository
        extends MongoRepository<StudentProfile, String> {

    Optional<StudentProfile> findByEmail(String email);
}
