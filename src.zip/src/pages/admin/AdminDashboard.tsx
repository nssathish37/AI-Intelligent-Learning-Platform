import { useEffect, useState } from "react";
import axios from "axios";
import { Users, GraduationCap, Brain, Briefcase } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function AdminDashboard() {

  const [data, setData] = useState<any>(null);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const res = await axios.get("/admin/analytics");
      setData(res.data);
    } catch (error) {
      console.error("Analytics error", error);
    }
  };

  if (!data) return <div className="p-10">Loading...</div>;

  const skillData = [
    { name: "Students", count: data.totalStudents },
    { name: "Instructors", count: data.totalInstructors },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-8">

      <h1 className="text-4xl font-bold text-white mb-8">
        🤖 AI Career System - Admin Analytics
      </h1>

      {/* Glass Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">

        <GlassCard title="Total Users" value={data.totalUsers} icon={<Users />} />
        <GlassCard title="Students" value={data.totalStudents} icon={<GraduationCap />} />
        <GlassCard title="Assessments" value={data.totalAssessments} icon={<Brain />} />
        <GlassCard title="Interviews" value={data.totalInterviews} icon={<Briefcase />} />

      </div>

      {/* Chart */}
      <div className="mt-10 backdrop-blur-lg bg-white/20 rounded-3xl p-6 shadow-2xl">

        <h2 className="text-2xl font-semibold text-white mb-4">
          📊 User Distribution
        </h2>

        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={skillData}>
            <XAxis dataKey="name" stroke="#fff" />
            <YAxis stroke="#fff" />
            <Tooltip />
            <Bar dataKey="count" fill="#ffffff" />
          </BarChart>
        </ResponsiveContainer>

      </div>

    </div>
  );
}

function GlassCard({ title, value, icon }: any) {
  return (
    <div className="backdrop-blur-lg bg-white/20 p-6 rounded-3xl shadow-2xl border border-white/30 hover:scale-105 transition">

      <div className="flex justify-between items-center text-white">
        <div>
          <p className="text-sm opacity-80">{title}</p>
          <h2 className="text-3xl font-bold">{value}</h2>
        </div>
        <div className="text-white">
          {icon}
        </div>
      </div>

    </div>
  );
}