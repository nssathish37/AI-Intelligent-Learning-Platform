const AdminProfile = () => {
  return (
    <div>
      <h1>Admin Profile</h1>
    </div>
  );
};

export default AdminProfile;