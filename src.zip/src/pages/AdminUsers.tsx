import { useEffect, useState } from "react";
import axios from "axios";
import MainLayout from "../components/layout/MainLayout";

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

const AdminUsers = () => {

  const [users, setUsers] = useState<User[]>([]);
  const [search, setSearch] = useState("");

  const token = localStorage.getItem("accessToken");

  const fetchUsers = () => {
    axios.get("http://localhost:8080/api/admin/users", {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => setUsers(res.data));
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const deleteUser = (id: string) => {
    axios.delete(`http://localhost:8080/api/admin/users/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(() => fetchUsers());
  };

  const updateRole = (id: string, role: string) => {
    axios.put(`http://localhost:8080/api/admin/users/${id}/role`,
      { role },
      { headers: { Authorization: `Bearer ${token}` } }
    ).then(() => fetchUsers());
  };

  const filteredUsers = users.filter(user =>
    user.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <MainLayout role="ADMIN">

      <h1 style={{ marginBottom: 20 }}>User Management</h1>

      <input
        placeholder="Search by email..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{
          padding: 10,
          marginBottom: 20,
          width: "300px",
          borderRadius: 5,
          border: "1px solid #ccc"
        }}
      />

      <table style={tableStyle}>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {filteredUsers.map(user => (
            <tr key={user.id}>
              <td>{user.name}</td>
              <td>{user.email}</td>

              <td>
                <select
                  value={user.role}
                  onChange={(e) =>
                    updateRole(user.id, e.target.value)
                  }
                >
                  <option value="STUDENT">STUDENT</option>
                  <option value="INSTRUCTOR">INSTRUCTOR</option>
                  <option value="ADMIN">ADMIN</option>
                </select>
              </td>

              <td>
                <button
                  onClick={() => deleteUser(user.id)}
                  style={deleteBtn}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

    </MainLayout>
  );
};

const tableStyle = {
  width: "100%",
  borderCollapse: "collapse" as const
};

const deleteBtn = {
  background: "red",
  color: "white",
  padding: "6px 12px",
  border: "none",
  borderRadius: "4px",
  cursor: "pointer"
};

export default AdminUsers;