import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { ProgressBar } from '../../components/common/ProgressBar';
import { getAllCourses } from '../../services/courseService';
import { Search, Filter, BookOpen } from 'lucide-react';
import { Input } from '../../components/common/Input';
export const Courses: React.FC = () => {
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await getAllCourses();
        setCourses(res.data);
      } catch (error) {
        console.error('Failed to fetch courses');
      } finally {
        setLoading(false);
      }
    };
    fetchCourses();
  }, []);
  return <DashboardLayout>
      <div className="relative -mx-6 -mt-6 mb-8 overflow-hidden rounded-b-2xl">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 opacity-10"></div>
        <div className="relative px-6 py-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-5 h-5 text-indigo-600" />
                <span className="text-sm font-medium text-indigo-600">
                  Explore & Learn
                </span>
              </div>
              <h1 className="text-3xl font-bold text-gray-900">
                Course Library
              </h1>
              <p className="text-gray-600 mt-1">
                Explore new skills and advance your career.
              </p>
            </div>
            <div className="flex gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input type="text" placeholder="Search courses..." className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 text-sm w-64 bg-white shadow-sm" />
              </div>
              <Button variant="outline" className="flex items-center gap-2 shadow-sm">
                <Filter className="w-4 h-4" /> Filter
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map(course => <Card key={course.id} className="flex flex-col h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="relative h-48 -mx-6 -mt-6 mb-4 overflow-hidden">
              <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover transition-transform duration-500 hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
              <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-1.5 rounded-full text-xs font-bold text-indigo-600 shadow-lg">
                {course.totalModules} Modules
              </div>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-xs font-bold text-white shadow-md">
                  {course.instructor.charAt(0)}
                </div>
                <span className="text-sm text-gray-600 font-medium">
                  {course.instructor}
                </span>
              </div>
              <h3 className="font-bold text-lg text-gray-900 mb-2 leading-tight">
                {course.title}
              </h3>
              <p className="text-sm text-gray-500 mb-4 line-clamp-2">
                {course.description}
              </p>

              {course.progress > 0 ? <div className="mb-4">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span className="font-medium">
                      {course.progress}% Complete
                    </span>
                  </div>
                  <ProgressBar progress={course.progress} />
                </div> : <div className="mb-4 h-4"></div>}
            </div>
            <Button variant={course.progress > 0 ? 'secondary' : 'primary'} fullWidth className="shadow-sm hover:shadow-md transition-shadow">
              {course.progress > 0 ? 'Continue Learning' : 'Enroll Now'}
            </Button>
          </Card>)}
      </div>
    </DashboardLayout>;
};