import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { saveStudentProfile, getStudentProfile } from "../../services/authService";

export const StudentProfile: React.FC = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  const [degree, setDegree] = useState("");
  const [department, setDepartment] = useState("");
  const [year, setYear] = useState("");
  const [careerGoal, setCareerGoal] = useState("");
  const [skillLevel, setSkillLevel] = useState("");
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const data = await getStudentProfile(user.email);

      if (data) {
        setDegree(data.degree || "");
        setDepartment(data.department || "");
        setYear(data.year || "");
        setCareerGoal(data.careerGoal || "");
        setSkillLevel(data.skillLevel || "");
        setEditing(true);
      }
    } catch (err) {
      console.log("No profile yet");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await saveStudentProfile(user.email, {
        degree,
        department,
        year,
        careerGoal,
        skillLevel,
      });

      alert(editing ? "Profile Updated!" : "Profile Saved!");
      navigate("/dashboard");

    } catch (error) {
      alert("Error saving profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-6">
      <div className="bg-white shadow-xl rounded-2xl w-full max-w-2xl p-8">
        <h2 className="text-2xl font-bold mb-6 text-center">
          Student Profile Setup
        </h2>

        <form onSubmit={handleSubmit} className="space-y-5">

          {/* 🔹 Name (Read Only) */}
          <div>
            <label className="block text-sm font-medium mb-1">Full Name</label>
            <input
              type="text"
              value={user.name || ""}
              disabled
              className="w-full bg-gray-100 border rounded-lg p-3"
            />
          </div>

          {/* 🔹 Email (Read Only) */}
          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input
              type="email"
              value={user.email || ""}
              disabled
              className="w-full bg-gray-100 border rounded-lg p-3"
            />
          </div>

          {/* Degree */}
          <div>
            <label className="block text-sm font-medium mb-1">Degree</label>
            <input
              type="text"
              value={degree}
              onChange={(e) => setDegree(e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              required
            />
          </div>

          {/* Department */}
          <div>
            <label className="block text-sm font-medium mb-1">Department</label>
            <input
              type="text"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              required
            />
          </div>

          {/* Year */}
          <div>
            <label className="block text-sm font-medium mb-1">Year</label>
            <input
              type="text"
              value={year}
              onChange={(e) => setYear(e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              required
            />
          </div>

          {/* Career Goal */}
          <div>
            <label className="block text-sm font-medium mb-1">Career Goal</label>
            <input
              type="text"
              value={careerGoal}
              onChange={(e) => setCareerGoal(e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              required
            />
          </div>

          {/* Skill Level */}
          <div>
            <label className="block text-sm font-medium mb-1">Skill Level</label>
            <select
              value={skillLevel}
              onChange={(e) => setSkillLevel(e.target.value)}
              className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none"
              required
            >
              <option value="">Select Level</option>
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition"
            disabled={loading}
          >
            {loading ? "Saving..." : editing ? "Update Profile" : "Save Profile"}
          </button>

        </form>
      </div>
    </div>
  );
};