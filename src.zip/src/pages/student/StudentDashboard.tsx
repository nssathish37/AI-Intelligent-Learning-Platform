import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { ProgressBar } from '../../components/common/ProgressBar';
import { SkillChart } from '../../components/charts/SkillChart';
import { ProgressChart } from '../../components/charts/ProgressChart';
import { getEnrolledCourses } from '../../services/courseService';
import { getStudentSkills } from '../../services/skillService';
import { BookOpen, PlayCircle, Trophy, ArrowRight, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
export const StudentDashboard: React.FC = () => {
  const [courses, setCourses] = useState<any[]>([]);
  const [skills, setSkills] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [coursesRes, skillsRes] = await Promise.all([getEnrolledCourses(), getStudentSkills()]);
        setCourses(coursesRes.data);
        setSkills(skillsRes.data);
      } catch (error) {
        console.error('Failed to fetch dashboard data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);
  return <DashboardLayout>
      {/* Hero Section with Subtle Background Pattern */}
      <div className="relative -mx-6 -mt-6 mb-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50"></div>
        <div className="absolute inset-0 opacity-30" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234f46e5' fill-opacity='0.15'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }}></div>

        <div className="relative z-10 px-6 py-8">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <span className="text-sm font-medium text-indigo-600">
              Your Learning Dashboard
            </span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, Student!
          </h1>
          <p className="text-gray-600">
            Here's what's happening with your learning journey today.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Stats Cards */}
        <Card className="bg-gradient-to-br from-indigo-500 to-indigo-600 text-white border-none shadow-lg hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-white/20 rounded-lg">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium bg-white/20 px-2 py-1 rounded">
              Active
            </span>
          </div>
          <h3 className="text-3xl font-bold mb-1">{courses.length}</h3>
          <p className="text-indigo-100 text-sm">Enrolled Courses</p>
        </Card>

        <Card className="bg-white shadow-lg hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-green-100 rounded-lg">
              <Trophy className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded">
              +12%
            </span>
          </div>
          <h3 className="text-3xl font-bold text-gray-900 mb-1">72%</h3>
          <p className="text-gray-500 text-sm">Job Readiness Score</p>
        </Card>

        <Card className="bg-white shadow-lg hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-purple-100 rounded-lg">
              <PlayCircle className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-xs font-medium text-purple-600 bg-purple-50 px-2 py-1 rounded">
              This Week
            </span>
          </div>
          <h3 className="text-3xl font-bold text-gray-900 mb-1">12h</h3>
          <p className="text-gray-500 text-sm">Learning Time</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card title="Skill Proficiency" className="shadow-lg">
          <SkillChart data={skills} />
        </Card>
        <Card title="Learning Progress" className="shadow-lg">
          <ProgressChart />
        </Card>
      </div>

      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-gray-900">Continue Learning</h2>
          <Link to="/courses" className="text-sm font-medium text-indigo-600 hover:text-indigo-500 flex items-center transition-colors">
            View All <ArrowRight className="w-4 h-4 ml-1" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.slice(0, 3).map(course => <Card key={course.id} className="flex flex-col h-full hover:shadow-xl transition-shadow">
              <div className="relative h-40 -mx-6 -mt-6 mb-4 overflow-hidden">
                <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover transition-transform duration-300 hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-gray-900 mb-2 line-clamp-1">
                  {course.title}
                </h3>
                <p className="text-sm text-gray-500 mb-4 line-clamp-2">
                  {course.description}
                </p>
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Progress</span>
                    <span>{course.progress}%</span>
                  </div>
                  <ProgressBar progress={course.progress} />
                </div>
              </div>
              <Button variant="secondary" fullWidth className="mt-auto">
                Continue
              </Button>
            </Card>)}
        </div>
      </div>
    </DashboardLayout>;
};