import React, { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { getFeedback } from '../../services/interviewService';
import { CheckCircle, Trophy, ArrowRight, Sparkles } from 'lucide-react';
export const InterviewFeedback: React.FC = () => {
  const location = useLocation();
  const sessionId = location.state?.sessionId;
  const [feedback, setFeedback] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (sessionId) {
      getFeedback(sessionId).then(res => {
        setFeedback(res.data);
        setLoading(false);
      });
    }
  }, [sessionId]);
  if (loading) {
    return <DashboardLayout>
        <div>Loading feedback...</div>
      </DashboardLayout>;
  }
  return <DashboardLayout>
      <div className="max-w-4xl mx-auto">
        {/* Celebratory Header with Background */}
        <div className="relative -mx-6 -mt-6 mb-10 overflow-hidden rounded-b-3xl">
          <div className="absolute inset-0 bg-gradient-to-br from-green-400 via-emerald-500 to-teal-600"></div>
          <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M50 50c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10s-10-4.477-10-10 4.477-10 10-10zM10 10c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10S0 25.523 0 20s4.477-10 10-10zm10 8c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm40 40c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>

          <div className="relative z-10 px-6 py-12 text-center text-white">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm mb-6 shadow-2xl">
              <Trophy className="w-12 h-12 text-white" />
            </div>
            <div className="flex items-center justify-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-yellow-300" />
              <span className="text-lg font-semibold text-white/90">
                Interview Complete
              </span>
              <Sparkles className="w-5 h-5 text-yellow-300" />
            </div>
            <h1 className="text-4xl font-bold mb-3">Great Job!</h1>
            <div className="inline-flex items-center gap-3 bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full mb-4">
              <span className="text-sm font-medium text-white/90">
                Your Score:
              </span>
              <span className="text-3xl font-bold text-white">
                {feedback.score}
              </span>
              <span className="text-sm font-medium text-white/90">/ 100</span>
            </div>
            <p className="text-lg text-white/90 max-w-2xl mx-auto">
              {feedback.feedback}
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {feedback.details.map((item: any, index: number) => <Card key={index} className="border-l-4 border-indigo-500 hover:shadow-lg transition-shadow">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
                    <span className="text-sm font-bold text-indigo-600">
                      {item.questionId}
                    </span>
                  </div>
                  <h3 className="font-bold text-gray-900">
                    Question {item.questionId}
                  </h3>
                </div>
                <Badge variant={item.score >= 80 ? 'success' : item.score >= 60 ? 'warning' : 'error'}>
                  Score: {item.score}/100
                </Badge>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                <p className="text-gray-700 text-sm bg-gradient-to-br from-gray-50 to-indigo-50/30 p-4 rounded-lg border border-gray-100">
                  {item.comment}
                </p>
              </div>
            </Card>)}
        </div>

        <div className="mt-10 flex justify-center gap-4">
          <Link to="/interview">
            <Button variant="secondary" className="shadow-md hover:shadow-lg transition-shadow">
              Practice Again
            </Button>
          </Link>
          <Link to="/jobs">
            <Button className="flex items-center shadow-md hover:shadow-lg transition-shadow">
              View Matched Jobs <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </DashboardLayout>;
};