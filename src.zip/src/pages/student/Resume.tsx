import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { useToast } from '../../context/ToastContext';
import { getResumeData, toggleAutoSubmit } from '../../services/resumeService';
import { Download, FileText, Check, AlertCircle } from 'lucide-react';
export const Resume: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [autoSubmit, setAutoSubmit] = useState(false);
  const {
    showToast
  } = useToast();
  useEffect(() => {
    getResumeData().then(res => {
      setData(res.data);
      setAutoSubmit(res.data.autoSubmit);
    });
  }, []);
  const handleDownload = () => {
    showToast('Resume downloaded successfully', 'success');
  };
  const handleAutoSubmitToggle = async () => {
    const newState = !autoSubmit;
    await toggleAutoSubmit(newState);
    setAutoSubmit(newState);
    showToast(`Auto-submit turned ${newState ? 'ON' : 'OFF'}`, 'info');
  };
  return <DashboardLayout>
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Resume Builder</h1>
          <p className="text-gray-600">
            Manage your AI-generated resume and application settings.
          </p>
        </div>
        <Button onClick={handleDownload} className="flex items-center gap-2">
          <Download className="w-4 h-4" /> Download PDF
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="min-h-[600px] p-8 bg-white shadow-lg border border-gray-200">
            {/* Mock Resume Preview */}
            <div className="animate-pulse space-y-4">
              <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
              <div className="h-4 bg-gray-200 rounded w-1/4 mb-8"></div>

              <div className="space-y-2 mb-8">
                <div className="h-4 bg-gray-200 rounded w-full"></div>
                <div className="h-4 bg-gray-200 rounded w-full"></div>
                <div className="h-4 bg-gray-200 rounded w-5/6"></div>
              </div>

              <div className="h-6 bg-gray-200 rounded w-1/4 mb-4"></div>
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="h-20 bg-gray-100 rounded"></div>
                <div className="h-20 bg-gray-100 rounded"></div>
                <div className="h-20 bg-gray-100 rounded"></div>
                <div className="h-20 bg-gray-100 rounded"></div>
              </div>
            </div>
            <div className="flex items-center justify-center h-full absolute inset-0">
              <p className="text-gray-400 font-medium">Resume Preview</p>
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Resume Score">
            <div className="flex flex-col items-center py-4">
              <div className="relative w-32 h-32 flex items-center justify-center mb-4">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="64" cy="64" r="56" stroke="#e5e7eb" strokeWidth="8" fill="transparent" />
                  <circle cx="64" cy="64" r="56" stroke="#10b981" strokeWidth="8" fill="transparent" strokeDasharray={351} strokeDashoffset={351 - 351 * (data?.score || 0) / 100} />
                </svg>
                <span className="absolute text-3xl font-bold text-gray-900">
                  {data?.score}
                </span>
              </div>
              <p className="text-center text-sm text-gray-600 mb-4">
                Your resume is strong! It matches 88% of target job
                descriptions.
              </p>
              <Button variant="outline" fullWidth size="sm">
                View Suggestions
              </Button>
            </div>
          </Card>

          <Card title="Auto-Apply Settings">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-gray-700">
                Auto-Submit
              </span>
              <button onClick={handleAutoSubmitToggle} className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${autoSubmit ? 'bg-indigo-600' : 'bg-gray-200'}`}>
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${autoSubmit ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>
            <p className="text-xs text-gray-500 mb-4">
              When enabled, our AI will automatically submit your resume to jobs
              with &gt;90% match score.
            </p>
            <div className="flex items-start gap-2 p-3 bg-yellow-50 rounded-lg border border-yellow-100">
              <AlertCircle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-yellow-700">
                By enabling this, you consent to automated applications on your
                behalf.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>;
};