import React, { useState } from 'react';
import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { Card } from '../../components/common/Card';
import { Button } from '../../components/common/Button';
import { startInterview, submitAnswer } from '../../services/interviewService';
import { Mic, Send, Clock, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
export const Interview: React.FC = () => {
  const [started, setStarted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [questions, setQuestions] = useState<any[]>([]);
  const [sessionId, setSessionId] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const handleStart = async () => {
    setLoading(true);
    try {
      const res = await startInterview();
      setSessionId(res.data.sessionId);
      setQuestions(res.data.questions);
      setStarted(true);
    } catch (error) {
      console.error('Failed to start interview');
    } finally {
      setLoading(false);
    }
  };
  const handleNext = async () => {
    if (!answer.trim()) return;
    setLoading(true);
    try {
      await submitAnswer(sessionId, questions[currentQuestionIndex].id, answer);
      setAnswer('');
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
      } else {
        navigate('/interview/feedback', {
          state: {
            sessionId
          }
        });
      }
    } catch (error) {
      console.error('Failed to submit answer');
    } finally {
      setLoading(false);
    }
  };
  if (!started) {
    return <DashboardLayout>
        {/* Hero Section with Background */}
        <div className="relative -mx-6 -mt-6 mb-8 overflow-hidden rounded-b-3xl">
          <div className="absolute inset-0 bg-cover bg-center" style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=1200&auto=format&fit=crop&q=80)'
        }}>
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/95 to-purple-700/90"></div>
          </div>

          <div className="relative z-10 px-6 py-16 text-center text-white">
            <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl">
              <Mic className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-4xl font-bold mb-4">AI Mock Interview</h1>
            <p className="text-lg text-indigo-100 max-w-2xl mx-auto">
              Practice with our AI interviewer to boost your confidence. You'll
              receive real-time feedback on your technical accuracy and
              communication style.
            </p>
          </div>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="bg-white border-l-4 border-indigo-500 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-gray-900 mb-2">
                Technical Questions
              </h3>
              <p className="text-sm text-gray-500">
                Curated based on your skill profile and target role.
              </p>
            </Card>
            <Card className="bg-white border-l-4 border-purple-500 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-gray-900 mb-2">Timed Responses</h3>
              <p className="text-sm text-gray-500">
                Simulate real interview pressure with time limits.
              </p>
            </Card>
            <Card className="bg-white border-l-4 border-green-500 hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-gray-900 mb-2">Instant Feedback</h3>
              <p className="text-sm text-gray-500">
                Get detailed analysis and improvement tips immediately.
              </p>
            </Card>
          </div>

          <div className="text-center">
            <Button size="lg" onClick={handleStart} isLoading={loading} className="px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-shadow">
              Start Interview Session
            </Button>
          </div>
        </div>
      </DashboardLayout>;
  }
  const currentQuestion = questions[currentQuestionIndex];
  return <DashboardLayout>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <span className="text-sm font-medium text-gray-500">
            Question {currentQuestionIndex + 1} of {questions.length}
          </span>
          <div className="flex items-center text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full text-sm font-medium">
            <Clock className="w-4 h-4 mr-1" /> 02:00
          </div>
        </div>

        <Card className="mb-6 border-indigo-100 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 mb-2">
            {currentQuestion.text}
          </h2>
          <div className="flex items-center text-sm text-gray-500 mt-4">
            <AlertCircle className="w-4 h-4 mr-1 text-indigo-500" />
            <span>Take your time to structure your answer before typing.</span>
          </div>
        </Card>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Your Answer
          </label>
          <textarea className="w-full h-64 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 resize-none" placeholder="Type your answer here..." value={answer} onChange={e => setAnswer(e.target.value)}></textarea>
        </div>

        <div className="flex justify-end">
          <Button onClick={handleNext} isLoading={loading} disabled={!answer.trim()} className="px-8">
            {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Submit Interview'}{' '}
            <Send className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </DashboardLayout>;
};