const InstructorProfile = () => {
  return (
    <div>
      <h1>Instructor Profile</h1>
    </div>
  );
};

export default InstructorProfile;