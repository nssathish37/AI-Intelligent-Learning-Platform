import MainLayout from "../../components/layout/MainLayout";
import { motion } from "framer-motion";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer
} from "recharts";

const data = [
  { name: "Jan", students: 30 },
  { name: "Feb", students: 50 },
  { name: "Mar", students: 80 },
  { name: "Apr", students: 120 },
];

const InstructorDashboard = () => {
  return (
    <MainLayout role="INSTRUCTOR">

      {/* Animated Cards */}
      <div className="grid grid-cols-3 gap-6 mb-10">

        {["Total Students", "Active Courses", "Pending Reviews"].map((title, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.2 }}
            className="bg-white rounded-2xl shadow-lg p-6"
          >
            <h3 className="text-gray-500">{title}</h3>
            <p className="text-3xl font-bold mt-2">
              {i === 0 ? 120 : i === 1 ? 8 : 15}
            </p>
          </motion.div>
        ))}

      </div>

      {/* Chart Section */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">
          Student Growth
        </h3>

        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="students" strokeWidth={3} />
          </LineChart>
        </ResponsiveContainer>
      </div>

    </MainLayout>
  );
};

export default InstructorDashboard;