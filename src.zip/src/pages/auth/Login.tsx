import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { login, verifyOtp } from '../../services/authService';
import { ROLES } from '../../utils/constants';
import { checkStudentProfile } from '../../services/authService';
import { Sparkles, Zap, Rocket, MessageSquare, ArrowRight, Eye, EyeOff } from 'lucide-react';

export const Login: React.FC = () => {
  const [step, setStep] = useState<'credentials' | 'otp'>('credentials');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState(ROLES.STUDENT);
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);

  const { loginUser } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    setIsVisible(true);
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await login({ email, password, role });
      
      showToast('OTP sent! Please check your email.', 'success');
      setStep('otp');

    } catch (error: any) {
    const message =
      error.response?.data?.error ||
      error.response?.data?.message ||
      'Invalid credentials.';

    showToast(message, 'error');
  } finally {
    setIsLoading(false);
  }
};

  const handleOtpSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setIsLoading(true);

  try {
    const result = await verifyOtp(email, otp.trim());

    const { user, accessToken, refreshToken } = result;

    localStorage.setItem("accessToken", accessToken);
    localStorage.setItem("refreshToken", refreshToken);
    localStorage.setItem("user", JSON.stringify(user));

    loginUser(user, accessToken, refreshToken);

    showToast("Login successful!", "success");

    if (user.role === ROLES.STUDENT) {

      const profileStatus = await checkStudentProfile(user.email);

      if (profileStatus.profileCompleted) {
        navigate("/dashboard");
      } else {
        navigate("/student/profile");
      }

    } else if (user.role === ROLES.INSTRUCTOR) {
      navigate("/instructor/dashboard");
    } else if (user.role === ROLES.ADMIN) {
      navigate("/admin/dashboard");
    }

  } catch (error: any) {
    showToast("Invalid OTP. Please try again.", "error");
  } finally {
    setIsLoading(false);
  }
};

  const roleConfig = {
    STUDENT: {
      icon: Sparkles,
      gradient: 'from-blue-500 to-cyan-500',
      hoverGradient: 'from-blue-600 to-cyan-600',
      shadow: 'shadow-blue-500/50'
    },
    INSTRUCTOR: {
      icon: Zap,
      gradient: 'from-purple-500 to-pink-500',
      hoverGradient: 'from-purple-600 to-pink-600',
      shadow: 'shadow-purple-500/50'
    },
    ADMIN: {
      icon: Rocket,
      gradient: 'from-orange-500 to-red-500',
      hoverGradient: 'from-orange-600 to-red-600',
      shadow: 'shadow-orange-500/50'
    }
  };

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      {/* Animated Background with Floating Orbs */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        {/* Animated gradient overlay that follows mouse */}
        <div
          className="absolute inset-0 opacity-30 transition-all duration-1000 ease-out"
          style={{
            background: `radial-gradient(circle 800px at ${mousePosition.x}px ${mousePosition.y}px, rgba(99, 102, 241, 0.3), transparent 50%)`
          }}
        />

        {/* Floating color orbs */}
        <div className="absolute top-20 left-20 w-72 h-72 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-20 left-40 w-72 h-72 bg-gradient-to-r from-orange-400 to-red-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>

        {/* Grid pattern overlay */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `linear-gradient(rgba(99, 102, 241, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(99, 102, 241, 0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      {/* Left side - Animated content */}
      <div className="hidden lg:flex lg:w-1/2 relative z-10 items-center justify-center p-12">
        <div className={`max-w-lg transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-5xl font-bold mb-6 leading-tight bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
            Transform Your Career with AI-Powered Learning
          </h1>

          <p className="text-xl text-gray-300 leading-relaxed mb-8">
            Master new skills, practice with AI interviews, and land your dream
            job with personalized guidance.
          </p>

          <div className="space-y-4">
            {[
              { icon: '🎯', title: 'Personalized Learning', desc: 'AI-curated courses tailored to your goals' },
              { icon: '🤖', title: 'AI Mock Interviews', desc: 'Practice with intelligent feedback' },
              { icon: '💼', title: 'Smart Job Matching', desc: 'Get matched with perfect opportunities' }
            ].map((feature, index) => (
              <div
                key={index}
                className={`flex items-start gap-4 p-4 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300 hover:translate-x-2 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <span className="text-3xl">{feature.icon}</span>
                <div>
                  <h3 className="font-semibold text-white mb-1">{feature.title}</h3>
                  <p className="text-sm text-gray-400">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right side - Interactive Form */}
      <div className="flex-1 flex items-center justify-center p-8 relative z-10">
        <div className={`w-full max-w-md transition-all duration-1000 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          {/* Glass morphism card */}
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 p-8 relative overflow-hidden">
            {/* Animated gradient border effect */}
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"></div>

            <div className="relative z-10">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-white mb-2">
                  {step === 'credentials' ? 'Welcome Back' : 'Verify Identity'}
                </h2>
                <p className="text-gray-300">
                  {step === 'credentials' ? 'Sign in to continue your journey' : `Enter the OTP sent to ${email}`}
                </p>
              </div>

              {step === 'credentials' ? (
                <form className="space-y-5" onSubmit={handleCredentialsSubmit}>
                  {/* Enhanced Input Fields */}
                  <div className="group">
                    <label className="block text-sm font-medium text-gray-200 mb-2">Email address</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      placeholder="you@example.com"
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm hover:bg-white/15"
                    />
                  </div>

                  <div className="group">
                    <label className="block text-sm font-medium text-gray-200 mb-2">Password</label>
                    <div className="relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        placeholder="••••••••"
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm hover:bg-white/15 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                      >
                        {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                  </div>

                  {/* Interactive Role Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-200 mb-3">Select Your Role</label>
                    <div className="grid grid-cols-3 gap-3">
                      {Object.entries(roleConfig).map(([key, config]) => {
                        const Icon = config.icon;
                        const isSelected = role === key;
                        return (
                          <button
                            key={key}
                            type="button"
                            onClick={() => setRole(key as any)}
                            className={`relative p-4 rounded-xl border-2 transition-all duration-300 transform hover:scale-105 ${isSelected
                              ? `bg-gradient-to-br ${config.gradient} border-transparent shadow-lg ${config.shadow} scale-105`
                              : 'bg-white/5 border-white/20 hover:bg-white/10 hover:border-white/30'
                              }`}
                          >
                            <Icon className={`w-6 h-6 mx-auto mb-2 ${isSelected ? 'text-white' : 'text-gray-400'}`} />
                            <span className={`text-xs font-medium block ${isSelected ? 'text-white' : 'text-gray-300'}`}>
                              {key}
                            </span>
                            {isSelected && (
                              <div className="absolute inset-0 rounded-xl bg-white/20"></div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <label className="flex items-center text-gray-300 cursor-pointer group">
                      <input type="checkbox" className="w-4 h-4 rounded border-white/30 bg-white/10 text-blue-500 focus:ring-2 focus:ring-blue-500 focus:ring-offset-0 transition-all" />
                      <span className="ml-2 group-hover:text-white transition-colors">Remember me</span>
                    </label>
                    <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors font-medium">Forgot password?</a>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className={`w-full py-3 px-4 rounded-xl font-semibold text-white shadow-lg transition-all duration-300 transform hover:scale-105 ${isLoading
                      ? 'bg-gray-500 cursor-not-allowed'
                      : `bg-gradient-to-r ${roleConfig[role as keyof typeof roleConfig].gradient} hover:${roleConfig[role as keyof typeof roleConfig].hoverGradient} ${roleConfig[role as keyof typeof roleConfig].shadow}`
                      }`}
                  >
                    {isLoading ? (
                      <span className="flex items-center justify-center">
                        <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        Sending OTP...
                      </span>
                    ) : (
                      <span className="flex items-center justify-center">
                        Sign In <ArrowRight className="ml-2 w-4 h-4" />
                      </span>
                    )}
                  </button>
                </form>
              ) : (
                <form className="space-y-5" onSubmit={handleOtpSubmit}>
                  <div className="group">
                    <label className="block text-sm font-medium text-gray-200 mb-2">Enter OTP</label>
                    <div className="relative">
                      <MessageSquare className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                      <input
                        type="text"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        required
                        placeholder="123456"
                        maxLength={6}
                        className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm hover:bg-white/15 tracking-widest text-lg"
                      />
                    </div>
                    <p className="text-xs text-gray-400 mt-2">
                      Please check your email for the 6-digit verification code.
                      <br />
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 px-4 rounded-xl font-semibold text-white shadow-lg transition-all duration-300 transform hover:scale-105 bg-gradient-to-r from-blue-500 to-cyan-500 hover:shadow-2xl"
                  >
                    {isLoading ? (
                      <span className="flex items-center justify-center">
                        <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        Verifying...
                      </span>
                    ) : (
                      'Verify & Login'
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setStep('credentials')}
                    className="w-full py-2 text-sm text-gray-400 hover:text-white transition-colors"
                  >
                    Back to login
                  </button>
                </form>
              )}

              <div className="mt-6 text-center">
                <p className="text-gray-300">
                  Don't have an account?{' '}
                  <Link to="/signup" className="font-semibold text-blue-400 hover:text-blue-300 transition-colors">
                    Sign up for free
                  </Link>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};