import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '../../context/ToastContext';
import { register, sendOtp, verifyOtp } from '../../services/authService';
import { ROLES } from '../../utils/constants';
import { UserPlus, GraduationCap, BookOpen, MessageSquare, ArrowRight, Eye, EyeOff } from 'lucide-react';

export const Signup: React.FC = () => {
    const [step, setStep] = useState<'details' | 'otp'>('details');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [role, setRole] = useState(ROLES.STUDENT);
    const [otp, setOtp] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
    const [isVisible, setIsVisible] = useState(false);
    const { showToast } = useToast();
    const navigate = useNavigate();

    useEffect(() => {
        setIsVisible(true);
        const handleMouseMove = (e: MouseEvent) => {
            setMousePosition({ x: e.clientX, y: e.clientY });
        };
        window.addEventListener('mousemove', handleMouseMove);
        return () => window.removeEventListener('mousemove', handleMouseMove);
    }, []);

    const handleDetailsSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            // First validate details by calling register (without completing it)
            await register({ name, email, password, role });
            // If valid, send OTP
            await sendOtp(email);
            // NEW REAL CODE
            showToast('OTP sent! Please check your inbox for verification.', 'success');
            setStep('otp');
        } catch (error) {
            // Error handling is generic here, assumes register throws if invalid
            showToast('Registration failed. Please check your details.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const handleOtpSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            await verifyOtp(email, otp);
            showToast('Registration successful! Please login.', 'success');
            navigate('/login');
        } catch (error) {
            showToast('Invalid OTP. Please try again.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const roleConfig = {
        STUDENT: {
            icon: GraduationCap,
            gradient: 'from-emerald-500 to-teal-500',
            description: 'Learn and grow your skills'
        },
        INSTRUCTOR: {
            icon: BookOpen,
            gradient: 'from-violet-500 to-purple-500',
            description: 'Share your knowledge'
        }
    };

    return (
        <div className="min-h-screen flex relative overflow-hidden">
            {/* Animated Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900">
                <div
                    className="absolute inset-0 opacity-30 transition-all duration-1000 ease-out"
                    style={{
                        background: `radial-gradient(circle 800px at ${mousePosition.x}px ${mousePosition.y}px, rgba(139, 92, 246, 0.3), transparent 50%)`
                    }}
                />

                {/* Floating orbs */}
                <div className="absolute top-20 right-20 w-72 h-72 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
                <div className="absolute bottom-20 left-20 w-72 h-72 bg-gradient-to-r from-violet-400 to-purple-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
                <div className="absolute top-1/2 left-1/2 w-72 h-72 bg-gradient-to-r from-pink-400 to-rose-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>

                {/* Grid pattern */}
                <div
                    className="absolute inset-0 opacity-10"
                    style={{
                        backgroundImage: `linear-gradient(rgba(139, 92, 246, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(139, 92, 246, 0.1) 1px, transparent 1px)`,
                        backgroundSize: '50px 50px'
                    }}
                />
            </div>

            {/* Left side - Animated content */}
            <div className="hidden lg:flex lg:w-1/2 relative z-10 items-center justify-center p-12">
                <div className={`max-w-lg transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
                    <div className="mb-8 animate-float">
                        <div className="w-20 h-20 bg-gradient-to-br from-emerald-400 via-teal-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-2xl shadow-teal-500/50">
                            <UserPlus className="w-10 h-10 text-white" />
                        </div>
                    </div>

                    <h1 className="text-5xl font-bold mb-6 leading-tight bg-gradient-to-r from-white via-emerald-100 to-teal-100 bg-clip-text text-transparent">
                        Begin Your Learning Adventure
                    </h1>

                    <p className="text-xl text-gray-300 leading-relaxed mb-8">
                        Join thousands of learners transforming their careers with
                        AI-powered education.
                    </p>
                </div>
            </div>

            {/* Right side - Registration Form */}
            <div className="flex-1 flex items-center justify-center p-8 relative z-10">
                <div className={`w-full max-w-md transition-all duration-1000 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
                    <div className="bg-white/10 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 p-8 relative overflow-hidden">
                        <div className="relative z-10">
                            <div className="text-center mb-8">
                                <h2 className="text-3xl font-bold text-white mb-2">
                                    {step === 'details' ? 'Create Account' : 'Verify Email'}
                                </h2>
                                <p className="text-gray-300">
                                    {step === 'details' ? 'Start your learning journey today' : `Enter the OTP sent to ${email}`}
                                </p>
                            </div>

                            {step === 'details' ? (
                                <form className="space-y-5" onSubmit={handleDetailsSubmit}>
                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-200 mb-2">Full Name</label>
                                        <input
                                            type="text"
                                            value={name}
                                            onChange={(e) => setName(e.target.value)}
                                            required
                                            placeholder="John Doe"
                                            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm hover:bg-white/15"
                                        />
                                    </div>

                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-200 mb-2">Email address</label>
                                        <input
                                            type="email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            required
                                            placeholder="you@example.com"
                                            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm hover:bg-white/15"
                                        />
                                    </div>

                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-200 mb-2">Password</label>
                                        <div className="relative">
                                            <input
                                                type={showPassword ? "text" : "password"}
                                                value={password}
                                                onChange={(e) => setPassword(e.target.value)}
                                                required
                                                placeholder="••••••••"
                                                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm hover:bg-white/15 pr-10"
                                            />
                                            <button
                                                type="button"
                                                onClick={() => setShowPassword(!showPassword)}
                                                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                                            >
                                                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                                            </button>
                                        </div>
                                    </div>

                                    {/* Interactive Role Selection */}
                                    <div>
                                        <label className="block text-sm font-medium text-gray-200 mb-3">I am a</label>
                                        <div className="grid grid-cols-2 gap-4">
                                            {Object.entries(roleConfig).map(([key, config]) => {
                                                const Icon = config.icon;
                                                const isSelected = role === key;
                                                return (
                                                    <button
                                                        key={key}
                                                        type="button"
                                                        onClick={() => setRole(key as any)}
                                                        className={`relative p-5 rounded-xl border-2 transition-all duration-300 transform hover:scale-105 ${isSelected
                                                            ? `bg-gradient-to-br ${config.gradient} border-transparent shadow-lg shadow-${key === 'STUDENT' ? 'emerald' : 'violet'}-500/50 scale-105`
                                                            : 'bg-white/5 border-white/20 hover:bg-white/10 hover:border-white/30'
                                                            }`}
                                                    >
                                                        <Icon className={`w-8 h-8 mx-auto mb-2 ${isSelected ? 'text-white' : 'text-gray-400'}`} />
                                                        <span className={`text-sm font-semibold block mb-1 ${isSelected ? 'text-white' : 'text-gray-300'}`}>
                                                            {key}
                                                        </span>
                                                        <span className={`text-xs block ${isSelected ? 'text-white/80' : 'text-gray-400'}`}>
                                                            {config.description}
                                                        </span>
                                                    </button>
                                                );
                                            })}
                                        </div>
                                    </div>

                                    <button
                                        type="submit"
                                        disabled={isLoading}
                                        className={`w-full py-3 px-4 rounded-xl font-semibold text-white shadow-lg transition-all duration-300 transform hover:scale-105 ${isLoading
                                            ? 'bg-gray-500 cursor-not-allowed'
                                            : `bg-gradient-to-r ${roleConfig[role as keyof typeof roleConfig].gradient} hover:shadow-2xl`
                                            }`}
                                    >
                                        {isLoading ? (
                                            <span className="flex items-center justify-center">
                                                <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
                                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                                                </svg>
                                                Sending OTP...
                                            </span>
                                        ) : (
                                            <span className="flex items-center justify-center">
                                                Register <ArrowRight className="ml-2 w-4 h-4" />
                                            </span>
                                        )}
                                    </button>
                                </form>
                            ) : (
                                <form className="space-y-5" onSubmit={handleOtpSubmit}>
                                    <div className="group">
                                        <label className="block text-sm font-medium text-gray-200 mb-2">Enter OTP</label>
                                        <div className="relative">
                                            <MessageSquare className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                                            <input
                                                type="text"
                                                value={otp}
                                                onChange={(e) => setOtp(e.target.value)}
                                                required
                                                placeholder="123456"
                                                maxLength={6}
                                                className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all duration-300 backdrop-blur-sm hover:bg-white/15 tracking-widest text-lg"
                                            />
                                        </div>
                                        <p className="text-xs text-gray-400 mt-2">
                                            Please check your email for the 6-digit verification code.
                                            <br />
                                        </p>
                                    </div>

                                    <button
                                        type="submit"
                                        disabled={isLoading}
                                        className="w-full py-3 px-4 rounded-xl font-semibold text-white shadow-lg transition-all duration-300 transform hover:scale-105 bg-gradient-to-r from-emerald-500 to-teal-500 hover:shadow-2xl"
                                    >
                                        {isLoading ? (
                                            <span className="flex items-center justify-center">
                                                <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
                                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                                                </svg>
                                                Verifying...
                                            </span>
                                        ) : (
                                            'Create Account'
                                        )}
                                    </button>

                                    <button
                                        type="button"
                                        onClick={() => setStep('details')}
                                        className="w-full py-2 text-sm text-gray-400 hover:text-white transition-colors"
                                    >
                                        Back to details
                                    </button>
                                </form>
                            )}

                            <div className="mt-6 text-center">
                                <p className="text-gray-300">
                                    Already have an account?{' '}
                                    <Link to="/login" className="font-semibold text-emerald-400 hover:text-emerald-300 transition-colors">
                                        Sign in
                                    </Link>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
