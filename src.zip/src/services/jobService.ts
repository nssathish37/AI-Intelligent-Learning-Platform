import api from './api';
const MOCK_JOBS = [{
  id: '1',
  title: 'Frontend Developer',
  company: 'TechCorp Inc.',
  location: 'Remote',
  matchPercentage: 95,
  status: 'Interview',
  logo: 'https://ui-avatars.com/api/?name=Tech+Corp&background=0D8ABC&color=fff',
  posted: '2 days ago'
}, {
  id: '2',
  title: 'Junior Java Developer',
  company: 'FinSystems',
  location: 'New York, NY',
  matchPercentage: 82,
  status: 'Sent',
  logo: 'https://ui-avatars.com/api/?name=Fin+Sys&background=6366f1&color=fff',
  posted: '1 week ago'
}, {
  id: '3',
  title: 'Full Stack Engineer',
  company: 'StartupXYZ',
  location: 'San Francisco, CA',
  matchPercentage: 65,
  status: null,
  logo: 'https://ui-avatars.com/api/?name=Start+Up&background=10b981&color=fff',
  posted: '3 days ago'
}];
export const getMatchedJobs = async () => {
  // return api.get('/jobs/matched');
  await new Promise(resolve => setTimeout(resolve, 800));
  return {
    data: MOCK_JOBS
  };
};
export const applyToJob = async (jobId: string) => {
  // return api.post(`/jobs/${jobId}/apply`);
  await new Promise(resolve => setTimeout(resolve, 1000));
  return {
    success: true
  };
};