import api from './api';
const MOCK_QUESTIONS = [{
  id: 1,
  text: 'Explain the difference between useMemo and useCallback in React.'
}, {
  id: 2,
  text: 'What are the key principles of RESTful APIs?'
}, {
  id: 3,
  text: 'How does the Java Garbage Collection work?'
}];
export const startInterview = async () => {
  // return api.post('/interview/start');
  await new Promise(resolve => setTimeout(resolve, 1000));
  return {
    data: {
      sessionId: 'session-123',
      questions: MOCK_QUESTIONS
    }
  };
};
export const submitAnswer = async (sessionId: string, questionId: number, answer: string) => {
  // return api.post(`/interview/${sessionId}/answer`, { questionId, answer });
  await new Promise(resolve => setTimeout(resolve, 500));
  return {
    success: true
  };
};
export const getFeedback = async (sessionId: string) => {
  // return api.get(`/interview/${sessionId}/feedback`);
  await new Promise(resolve => setTimeout(resolve, 1500));
  return {
    data: {
      score: 85,
      feedback: 'Strong technical knowledge shown. Try to provide more concrete examples in your explanations.',
      details: [{
        questionId: 1,
        score: 90,
        comment: 'Excellent explanation of memoization.'
      }, {
        questionId: 2,
        score: 80,
        comment: 'Good, but missed HATEOAS.'
      }, {
        questionId: 3,
        score: 85,
        comment: 'Solid understanding of generations.'
      }]
    }
  };
};