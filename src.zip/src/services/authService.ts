import axios from "axios";
import {
  getAccessToken,
  getRefreshToken,
  clearAuth
} from "../utils/tokenManager";

const api = axios.create({
  baseURL: "http://localhost:8080/api",
});

// 🔐 Attach Access Token to every request
api.interceptors.request.use((config) => {
  const token = getAccessToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// 🔁 Automatic Refresh Token Logic
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (
      error.response?.status === 401 &&
      !originalRequest._retry
    ) {
      originalRequest._retry = true;

      try {
        const refreshToken = getRefreshToken();

        const response = await axios.post(
          "http://localhost:8080/api/auth/refresh",
          { refreshToken }
        );

        const newAccessToken = response.data.accessToken;

        localStorage.setItem("accessToken", newAccessToken);

        originalRequest.headers.Authorization =
          `Bearer ${newAccessToken}`;

        return api(originalRequest);

      } catch (err) {
        clearAuth();
        window.location.href = "/login";
      }
    }

    return Promise.reject(error);
  }
);

// 🔐 LOGIN
export const login = async (data: any) => {
  const response = await api.post("/auth/login", data);
  return response.data;
};

// 🔐 REGISTER
export const register = async (data: any) => {
  const response = await api.post("/auth/register", data);
  return response.data;
};

// 📩 SEND OTP
export const sendOtp = async (email: string) => {
  const response = await api.post("/auth/send-otp", { email });
  return response.data;
};

// 🔐 VERIFY OTP
export const verifyOtp = async (email: string, otp: string) => {
  const response = await api.post("/auth/verify-otp", { email, otp });
  return response.data;
};

// 🚪 LOGOUT
export const logoutApi = async (email: string) => {
  await api.post("/auth/logout", { email });
};

export const getStudentProfile = async (email: string) => {
  const response = await api.get(
    `/auth/student/profile?email=${email}`
  );
  return response.data;
};

export const checkStudentProfile = async (email: string) => {
  const response = await api.get(
    `/auth/student/profile/check?email=${email}`
  );
  return response.data;
};

export const saveStudentProfile = async (email: string, data: any) => {
  const response = await api.post(
    `/auth/student/profile?email=${email}`,
    data
  );
  return response.data;
};

export default api;