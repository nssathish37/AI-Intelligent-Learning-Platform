import api from './api';
export const getResumeData = async () => {
  // return api.get('/student/resume');
  await new Promise(resolve => setTimeout(resolve, 700));
  return {
    data: {
      score: 88,
      url: '#',
      autoSubmit: true,
      lastUpdated: '2023-10-15'
    }
  };
};
export const toggleAutoSubmit = async (enabled: boolean) => {
  // return api.put('/student/resume/autosubmit', { enabled });
  await new Promise(resolve => setTimeout(resolve, 500));
  return {
    success: true,
    enabled
  };
};