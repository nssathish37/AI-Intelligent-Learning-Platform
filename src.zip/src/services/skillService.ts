import api from './api';
const MOCK_SKILLS = [{
  name: 'React',
  level: 85,
  category: 'Frontend'
}, {
  name: 'JavaScript',
  level: 90,
  category: 'Frontend'
}, {
  name: 'Java',
  level: 60,
  category: 'Backend'
}, {
  name: 'Spring Boot',
  level: 55,
  category: 'Backend'
}, {
  name: 'MongoDB',
  level: 70,
  category: 'Database'
}, {
  name: 'System Design',
  level: 40,
  category: 'Architecture'
}];
export const getStudentSkills = async () => {
  // return api.get('/student/skills');
  await new Promise(resolve => setTimeout(resolve, 600));
  return {
    data: MOCK_SKILLS
  };
};
export const getReadinessScore = async () => {
  await new Promise(resolve => setTimeout(resolve, 400));
  return {
    data: {
      score: 72,
      label: 'Job Ready'
    }
  };
};