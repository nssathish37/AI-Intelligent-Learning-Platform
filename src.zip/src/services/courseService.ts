import api from './api';

// Mock data
const MOCK_COURSES = [{
  id: '1',
  title: 'Advanced React Patterns',
  description: 'Master modern React with hooks, context, and performance optimization.',
  instructor: 'Sarah Smith',
  progress: 45,
  totalModules: 10,
  completedModules: 4,
  thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
}, {
  id: '2',
  title: 'Spring Boot Microservices',
  description: 'Build scalable backend systems with Spring Boot and Cloud.',
  instructor: 'Mike Johnson',
  progress: 10,
  totalModules: 12,
  completedModules: 1,
  thumbnail: 'https://images.unsplash.com/photo-1605379399642-870262d3d051?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
}, {
  id: '3',
  title: 'Data Structures & Algorithms',
  description: 'Prepare for technical interviews with comprehensive DSA coverage.',
  instructor: 'Emily Chen',
  progress: 0,
  totalModules: 20,
  completedModules: 0,
  thumbnail: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
}];
export const getEnrolledCourses = async () => {
  // return api.get('/student/courses');
  await new Promise(resolve => setTimeout(resolve, 800));
  return {
    data: MOCK_COURSES
  };
};
export const getCourseById = async (id: string) => {
  // return api.get(`/courses/${id}`);
  await new Promise(resolve => setTimeout(resolve, 500));
  return {
    data: MOCK_COURSES.find(c => c.id === id) || MOCK_COURSES[0]
  };
};
export const getAllCourses = async () => {
  // return api.get('/courses');
  await new Promise(resolve => setTimeout(resolve, 800));
  return {
    data: MOCK_COURSES
  };
};