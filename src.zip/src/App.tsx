// import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { ProtectedRoute } from './routes/ProtectedRoute';
import { RoleBasedRoute } from './routes/RoleBasedRoute';
import { ROLES } from './utils/constants';
// Auth Pages
import { Login } from './pages/auth/Login';
import { Signup } from './pages/auth/Signup';

import { StudentProfile } from './pages/student/StudentProfile';

// Student Pages
import { StudentDashboard } from './pages/student/StudentDashboard';
import { Courses } from './pages/student/Courses';
import { Skills } from './pages/student/Skills';
import { Interview } from './pages/student/Interview';
import { InterviewFeedback } from './pages/student/InterviewFeedback';
import { Resume } from './pages/student/Resume';
import { Jobs } from './pages/student/Jobs';

// Admin Pages
import AdminUsers from './pages/AdminUsers';
import InstructorDashboard from "./pages/instructor/InstructorDashboard";
import AdminDashboard from "./pages/admin/AdminDashboard";
// Placeholder Pages for other roles
const Unauthorized = () => <div className="p-8 text-2xl text-red-600">Unauthorized Access</div>;
function App() {
  return <Router>
    <AuthProvider>
      <ToastProvider>
        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/student/profile" element={<StudentProfile />} />
          <Route path="/unauthorized" element={<Unauthorized />} />
          <Route path="/" element={<Navigate to="/login" replace />} />

          {/* Protected Routes */}
          <Route element={<ProtectedRoute />}>
            {/* Student Routes */}
            <Route element={<RoleBasedRoute allowedRoles={[ROLES.STUDENT]} />}>
              <Route path="/dashboard" element={<StudentDashboard />} />
              <Route path="/courses" element={<Courses />} />
              <Route path="/skills" element={<Skills />} />
              <Route path="/interview" element={<Interview />} />
              <Route path="/interview/feedback" element={<InterviewFeedback />} />
              <Route path="/resume" element={<Resume />} />
              <Route path="/jobs" element={<Jobs />} />
            </Route>

            {/* Instructor Routes */}
            <Route element={<RoleBasedRoute allowedRoles={[ROLES.INSTRUCTOR]} />}>
              <Route path="/instructor/dashboard" element={<InstructorDashboard />} />
            </Route>

            {/* Admin Routes */}
            <Route element={<RoleBasedRoute allowedRoles={[ROLES.ADMIN]} />}>
              <Route path="/admin/dashboard" element={<AdminDashboard />} />
              <Route path="/admin/users" element={<AdminUsers />} />
            </Route>
          </Route>
        </Routes>
      </ToastProvider>
    </AuthProvider>
  </Router>;
}
export { App };