export const API_BASE_URL = 'http://localhost:8080/api';
export const ROLES = {
  STUDENT: 'STUDENT',
  INSTRUCTOR: 'INSTRUCTOR',
  ADMIN: 'ADMIN'
};
export const ROUTES = {
  LOGIN: '/login',
  SIGNUP: '/signup',
  STUDENT_DASHBOARD: '/dashboard',
  INSTRUCTOR_DASHBOARD: '/instructor/dashboard',
  ADMIN_DASHBOARD: '/admin/dashboard'
};