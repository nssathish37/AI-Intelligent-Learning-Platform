import React from 'react';
interface ProgressBarProps {
  progress: number;
  className?: string;
  color?: string;
}
export const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  className = '',
  color = 'bg-indigo-600'
}) => {
  const clampedProgress = Math.min(Math.max(progress, 0), 100);
  return <div className={`w-full bg-gray-200 rounded-full h-2.5 ${className}`}>
      <div className={`${color} h-2.5 rounded-full transition-all duration-500 ease-out`} style={{
      width: `${clampedProgress}%`
    }}></div>
    </div>;
};