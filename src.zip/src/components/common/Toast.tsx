import React, { useEffect } from 'react';
import { X, CheckCircle, AlertCircle, Info } from 'lucide-react';
export type ToastType = 'success' | 'error' | 'info';
interface ToastProps {
  id: string;
  message: string;
  type: ToastType;
  onClose: (id: string) => void;
}
export const Toast: React.FC<ToastProps> = ({
  id,
  message,
  type,
  onClose
}) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose(id);
    }, 5000);
    return () => clearTimeout(timer);
  }, [id, onClose]);
  const icons = {
    success: <CheckCircle className="w-5 h-5 text-green-500" />,
    error: <AlertCircle className="w-5 h-5 text-red-500" />,
    info: <Info className="w-5 h-5 text-blue-500" />
  };
  const styles = {
    success: 'border-l-4 border-green-500 bg-white',
    error: 'border-l-4 border-red-500 bg-white',
    info: 'border-l-4 border-blue-500 bg-white'
  };
  return <div className={`flex items-center p-4 mb-3 shadow-lg rounded-r-lg w-80 transform transition-all duration-300 ease-in-out ${styles[type]}`}>
      <div className="mr-3">{icons[type]}</div>
      <div className="flex-1 text-sm font-medium text-gray-800">{message}</div>
      <button onClick={() => onClose(id)} className="ml-2 text-gray-400 hover:text-gray-600">
        <X className="w-4 h-4" />
      </button>
    </div>;
};