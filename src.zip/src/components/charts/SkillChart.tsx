import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from 'recharts';
interface SkillChartProps {
  data: Array<{
    name: string;
    level: number;
    fullMark?: number;
  }>;
}
export const SkillChart: React.FC<SkillChartProps> = ({
  data
}) => {
  return <div className="h-80 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
          <PolarGrid stroke="#e5e7eb" />
          <PolarAngleAxis dataKey="name" tick={{
          fill: '#4b5563',
          fontSize: 12
        }} />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar name="Skill Level" dataKey="level" stroke="#4f46e5" strokeWidth={2} fill="#6366f1" fillOpacity={0.4} />
          <Tooltip contentStyle={{
          borderRadius: '8px',
          border: 'none',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
        }} />
        </RadarChart>
      </ResponsiveContainer>
    </div>;
};