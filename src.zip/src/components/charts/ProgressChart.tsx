import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
const data = [{
  name: 'Week 1',
  progress: 20
}, {
  name: 'Week 2',
  progress: 35
}, {
  name: 'Week 3',
  progress: 45
}, {
  name: 'Week 4',
  progress: 60
}, {
  name: 'Week 5',
  progress: 75
}, {
  name: 'Week 6',
  progress: 85
}];
export const ProgressChart: React.FC = () => {
  return <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{
        top: 5,
        right: 20,
        bottom: 5,
        left: 0
      }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{
          fill: '#9ca3af',
          fontSize: 12
        }} />
          <YAxis axisLine={false} tickLine={false} tick={{
          fill: '#9ca3af',
          fontSize: 12
        }} />
          <Tooltip contentStyle={{
          borderRadius: '8px',
          border: 'none',
          boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
        }} />
          <Line type="monotone" dataKey="progress" stroke="#4f46e5" strokeWidth={3} dot={{
          r: 4,
          fill: '#4f46e5',
          strokeWidth: 2,
          stroke: '#fff'
        }} activeDot={{
          r: 6
        }} />
        </LineChart>
      </ResponsiveContainer>
    </div>;
};