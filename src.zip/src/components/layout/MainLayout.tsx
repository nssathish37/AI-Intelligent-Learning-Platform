import { ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { LayoutDashboard, Users, LogOut } from "lucide-react";

interface Props {
  children: ReactNode;
  role: string;
}

const MainLayout = ({ role, children }: Props) => {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("accessToken");
    navigate("/login");
  };

  return (
    <div className="flex h-screen bg-gray-100">

      {/* Sidebar */}
      <div className="w-64 bg-white shadow-xl p-6 flex flex-col">
        <h2 className="text-2xl font-bold mb-8 text-blue-600">
          AI Career System
        </h2>

        <Link to={`/${role.toLowerCase()}/dashboard`}
          className="flex items-center gap-2 mb-4 hover:text-blue-600 transition">
          <LayoutDashboard size={18} /> Dashboard
        </Link>

        {role === "ADMIN" && (
          <Link to="/admin/users"
            className="flex items-center gap-2 mb-4 hover:text-blue-600 transition">
            <Users size={18} /> Users
          </Link>
        )}

        <div className="mt-auto">
          <button onClick={logout}
            className="flex items-center gap-2 text-red-500 hover:text-red-700">
            <LogOut size={18} /> Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">

        {/* Topbar */}
        <div className="bg-white shadow-md p-4 flex justify-between items-center">
          <h1 className="text-xl font-semibold">
            {role} Dashboard
          </h1>

          <div className="flex items-center gap-3">
            <div className="bg-blue-500 text-white rounded-full w-10 h-10 flex items-center justify-center">
              S
            </div>
          </div>
        </div>

        <div className="p-8 overflow-auto">
          {children}
        </div>
      </div>

    </div>
  );
};

export default MainLayout;