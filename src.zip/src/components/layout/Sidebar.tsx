import React from 'react';
import { User as UserIcon } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { LayoutDashboard, BookOpen, Award, Briefcase, FileText, Video, Users, Building, PlusCircle, BarChart, } from 'lucide-react';
export const Sidebar: React.FC = () => {
  const {
    user
  } = useAuth();
  const role = user?.role;
  const getLinks = () => {
    switch (role) {
      case 'STUDENT':
        return [{
          to: '/dashboard',
          icon: <LayoutDashboard className="w-5 h-5" />,
          label: 'Dashboard'
        }, {
          to: '/courses',
          icon: <BookOpen className="w-5 h-5" />,
          label: 'My Courses'
        }, {
          to: '/skills',
          icon: <BarChart className="w-5 h-5" />,
          label: 'Skill Tracker'
        }, {
          to: '/interview',
          icon: <Video className="w-5 h-5" />,
          label: 'AI Interview'
        }, {
          to: '/resume',
          icon: <FileText className="w-5 h-5" />,
          label: 'Resume Builder'
        }, {
          to: '/jobs',
          icon: <Briefcase className="w-5 h-5" />,
          label: 'Job Matches'
        }, {
          to: '/student/profile',
          icon: <Users className="w-5 h-5" />,
          label: 'Edit Profile'
        }];
      case 'INSTRUCTOR':
        return [{
          to: '/instructor/dashboard',
          icon: <LayoutDashboard className="w-5 h-5" />,
          label: 'Dashboard'
        }, {
          to: '/instructor/courses',
          icon: <BookOpen className="w-5 h-5" />,
          label: 'My Courses'
        }, {
          to: '/instructor/upload',
          icon: <PlusCircle className="w-5 h-5" />,
          label: 'Upload Course'
        }, {
          to: '/instructor/assessments',
          icon: <Award className="w-5 h-5" />,
          label: 'Assessments'
        }, {
          to: '/instructor/students',
          icon: <UserIcon className="w-5 h-5" />,
          label: 'Student Performance'
        }];
      case 'ADMIN':
        return [{
          to: '/admin/dashboard',
          icon: <LayoutDashboard className="w-5 h-5" />,
          label: 'Dashboard'
        }, {
          to: '/admin/users',
          icon: <Users className="w-5 h-5" />,
          label: 'Manage Users'
        }, {
          to: '/admin/companies',
          icon: <Building className="w-5 h-5" />,
          label: 'Companies'
        }, {
          to: '/admin/jobs',
          icon: <Briefcase className="w-5 h-5" />,
          label: 'Job Vacancies'
        }];
      default:
        return [];
    }
  };
  return <aside className="hidden lg:flex flex-col w-64 bg-slate-900 text-white min-h-screen fixed left-0 top-0 bottom-0 z-20">
      <div className="h-16 flex items-center px-6 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center">
            <span className="font-bold text-white">AI</span>
          </div>
          <span className="text-xl font-bold tracking-tight">SkillPath</span>
        </div>
      </div>

      <nav className="flex-1 py-6 px-3 space-y-1">
        {getLinks().map(link => <NavLink key={link.to} to={link.to} className={({
        isActive
      }) => `flex items-center px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${isActive ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white'}`}>
            <span className="mr-3">{link.icon}</span>
            {link.label}
          </NavLink>)}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800 rounded-lg p-4">
          <p className="text-xs text-slate-400 uppercase font-semibold mb-2">
            Your Plan
          </p>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Pro Student</span>
            <span className="text-xs bg-indigo-500 px-1.5 py-0.5 rounded">
              PRO
            </span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-1.5">
            <div className="bg-indigo-500 h-1.5 rounded-full w-3/4"></div>
          </div>
        </div>
      </div>
    </aside>;
};